@extends('admin/templates/v_default')
@section('title', 'Ippmp | backup db')
@section('content')

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-12">
        <div class="card mt-3">
          <div class="card-header">
            <h3 class="card-title text-bold"></h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
                <h1>Halaman belum tersedia</h1>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
      <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
@endSection('content')
